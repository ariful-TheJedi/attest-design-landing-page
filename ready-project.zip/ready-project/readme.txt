
the sections
1.header(nav)
2.  basic quotes
    -title
    -form
3.Portfoilo
4.orderprocess
5.faq
6.why attest design
7.footer


list of services
===================
Background Removal
Clipping Path
Color Correction
E-coomer Product Image Editing
Ghost Mannequin
Image Masking
Photo Retouching services
Photography Post-Processing
Video production
