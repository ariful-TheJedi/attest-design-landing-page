import React, { useRef, useState, useEffect } from "react";
import "../App.css";

export default function BeforeAfterSlider({
  beforeSrc,
  afterSrc,
  altBefore = "Before",
  altAfter = "After",
  start = 50,
}) {
  const [hoverActive, setHoverActive] = useState(false);
  const wrapRef = useRef(null);
  const [pos, setPos] = useState(start); // %

  const clamp = (v) => Math.min(100, Math.max(0, v));

  const updateFromEvent = (e) => {
    const rect = wrapRef.current.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const p = ((clientX - rect.left) / rect.width) * 100;
    setPos(clamp(p));
  };

  const [drag, setDrag] = useState(false);

  useEffect(() => {
    const stopDrag = () => setDrag(false);
    window.addEventListener("mouseup", stopDrag);
    window.addEventListener("touchend", stopDrag);
    return () => {
      window.removeEventListener("mouseup", stopDrag);
      window.removeEventListener("touchend", stopDrag);
    };
  }, []);

  return (
        <div
        className="ba-slider"
        ref={wrapRef}
        onClick={() => setHoverActive(!hoverActive)}
        onMouseMove={(e) => hoverActive && updateFromEvent(e)}
        onTouchMove={(e) => drag && updateFromEvent(e)}  // keep drag for mobile
        >
      {/* After Image (full) */}
      <img src={afterSrc} alt={altAfter} className="ba-img" />

      {/* Before Image (clipped with clip-path) */}
      <img
        src={beforeSrc}
        alt={altBefore}
        className="ba-img ba-before"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
      />

      {/* Divider line */}
      <div className="ba-divider" style={{ left: `${pos}%` }} />

      {/* Handle */}
      <button
        type="button"
        className="ba-handle shadow-lg"
        style={{ left: `${pos}%` }}
        onMouseDown={() => setDrag(true)}
        onTouchStart={(e) => {
          setDrag(true);
          updateFromEvent(e);
        }}
      >
    {/* <div className="ba-grip">
        <i className="bi bi-diamond-fill"></i>
    </div> */}
      </button>
    </div>
  );
}
