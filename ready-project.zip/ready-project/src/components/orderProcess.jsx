import React from "react";
//import "bootstrap/dist/css/bootstrap.min.css";


const OrderProcess = () => {
  return (
<section className="order-process mb-3 text-center">
  <h3 className="m-1 text-primary">SIMPLE 3-STEP ORDER PROCESS</h3>
  <h4>Get your service done in 3 simple steps</h4>
  <div className="container">
    <div className="row g-4 justify-content-center">
      <div className="col-12 col-sm-6 col-md-4">
        <div className="image-wrapper rounded mx-auto">
          <img
            src="https://attestdesign.com/wp-content/themes/ktad/img/quote.png"
            alt="Step 1"
            className="img-fluid"
          />
        </div>
      </div>
      <div className="col-12 col-sm-6 col-md-4">
        <div className="image-wrapper rounded mx-auto">
          <img
            src="https://attestdesign.com/wp-content/themes/ktad/img/upload.png"
            alt="Step 2"
            className="img-fluid"
          />
        </div>
      </div>
      <div className="col-12 col-sm-6 col-md-4">
        <div className="image-wrapper rounded mx-auto">
          <img
            src="https://attestdesign.com/wp-content/themes/ktad/img/download.png"
            alt="Step 3"
            className="img-fluid"
          />
        </div>
      </div>
    </div>
  </div>
</section>
)};

export default OrderProcess;
