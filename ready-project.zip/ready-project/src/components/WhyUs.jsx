import React, { useState, useEffect, useRef } from "react";

// Card component
const SliderCard = ({ img, title, desc }) => {
  return (
    <div className="slider-card">
      <div className="slider-card-image">
        <img src={img} alt={title} />
      </div>
      <div className="slider-card-content">
        <h3>{title}</h3>
        <p>{desc}</p>
        <button className="slider-btn">Learn More</button>
      </div>
    </div>
  );
};

// Demo data
const slides = [
  { title: "100% Money Back Guarantee",
     desc: "If the final result doesn't meet your expectations, we will refund your payment. No hassle, no pressure. Start your project with peace of mind.",
    img: "https://assets.entrepreneur.com/content/3x2/2000/20160407153601-allowance-crowdfunding-personal-credit-money.jpeg" },
  { title: "Secure & Easy Payments", 
    desc: "Attest Design supports trusted methods including Stripe, PayPal, Mastercard, Visa, and Bank Transfer all backed by a secure and encrypted payment gateway.",
    img: "https://www.pngitem.com/pimgs/m/20-202327_icon-fast-safe-secure-fast-and-secure-icon.png" },
  { title: "Blazing Speed",
    desc: "Attest Design uses a high-speed FTP server, Amazon AWS hosting, and CDN integration to ensure lightning-fast uploads and top-level data security.",
    img: "https://www.uploadvr.com/content/images/size/w1200/2020/07/iron-man-vr-impulse-armor-flying.jpeg" },
  { title: "Easy Communication",
    desc: "Our client-friendly communication system ensures you're updated at every step through your preferred channels.",
    img: "https://img.freepik.com/free-vector/hand-drawn-business-communication-concept_52683-76159.jpg" },
];

const CarouselSlider = () => {
  const [current, setCurrent] = useState(0);
  const wrapperRef = useRef(null);
  const slideRef = useRef(null);
  const startX = useRef(0);
  const isDragging = useRef(false);
  const slideInterval = useRef(null);
  const slideWidth = useRef(0);

  // Calculate slide width (including margin)
  useEffect(() => {
    const resizeHandler = () => {
      if (slideRef.current) {
        slideWidth.current = slideRef.current.offsetWidth + 20; // card width + gap
        updatePosition();
      }
    };
    resizeHandler();
    window.addEventListener("resize", resizeHandler);
    return () => window.removeEventListener("resize", resizeHandler);
  }, [current]);

  const updatePosition = () => {
    if (wrapperRef.current) {
      wrapperRef.current.style.transform = `translateX(-${
        current * slideWidth.current
      }px)`;
    }
  };

  const nextSlide = () => setCurrent((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrent((prev) => (prev - 1 + slides.length) % slides.length);

  Autoplay
  useEffect(() => {
    slideInterval.current = setInterval(nextSlide, 5000);
    return () => clearInterval(slideInterval.current);
  }, []);

  useEffect(() => {
    updatePosition();
  }, [current]);

  // Drag/Swipe
  const handleStart = (e) => {
    isDragging.current = true;
    startX.current = e.type.includes("mouse") ? e.clientX : e.touches[0].clientX;
    clearInterval(slideInterval.current);
    wrapperRef.current.style.transition = "none";
  };

  const handleMove = (e) => {
    if (!isDragging.current) return;
    const x = e.type.includes("mouse") ? e.clientX : e.touches[0].clientX;
    const diff = x - startX.current;
    wrapperRef.current.style.transform = `translateX(calc(-${
      current * slideWidth.current
    }px + ${diff}px))`;
  };

  const handleEnd = (e) => {
    if (!isDragging.current) return;
    isDragging.current = false;
    const x = e.type.includes("mouse") ? e.clientX : e.changedTouches[0].clientX;
    const diff = x - startX.current;
    wrapperRef.current.style.transition = "transform 0.5s ease";

    if (diff > 50) prevSlide();
    else if (diff < -50) nextSlide();
    else updatePosition();

    slideInterval.current = setInterval(nextSlide, 4000);
  };

  return (
    <div className="carousel-container">
      <div
        className="carousel-wrapper"
        ref={wrapperRef}
        onMouseDown={handleStart}
        onMouseMove={handleMove}
        onMouseUp={handleEnd}
        onMouseLeave={handleEnd}
        onTouchStart={handleStart}
        onTouchMove={handleMove}
        onTouchEnd={handleEnd}
      >
        {slides.map((slide, idx) => (
          <div
            key={idx}
            ref={idx === 0 ? slideRef : null} // measure only first card
            className={`slide ${idx === current ? "active" : ""}`}
          >
            <SliderCard {...slide} />
          </div>
        ))}
      </div>

      <div className="dots">
        {slides.map((_, idx) => (
          <span
            key={idx}
            className={`dot ${idx === current ? "active-dot" : ""}`}
            onClick={() => setCurrent(idx)}
          />
        ))}
      </div>
    </div>
  );
};



export default function WhyUs(){

  return (
  <section className="why-us py-5 text-center">
    <center>
     <h2>Why Attest Design is Your Ultimate Image Editing<br/> & Video Production Partner?</h2>
    </center>
   <CarouselSlider/>
  </section>
)}