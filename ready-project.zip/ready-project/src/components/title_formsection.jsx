import React from "react";
import ContactForm from "./contactForm";



function Intro(){


    return(<div className="intro-section my-1">
        <h3>
            Flawless photo & video editing with your proposed price
        </h3>
        <h1>
           <span className="span1">You Set the Price!</span>
           <br/><span className="span2">We deliver the perfection</span>
        </h1>
        <p>
          Professional photo and video editing services designed for your budget. Try us for free trial, then name your price.
        </p>
    </div>)
}


function TwoColumnComponent(){
  return (
    <div className="container my-5">
      <div className="row">
        {/* First Div */}
        <div className="intro-container col-12 col-md-6">
          <Intro/>
        </div>

        {/* Second Div */}
        <div className="col-12 col-md-6">
          <ContactForm/>
        </div>
      </div>
    </div>
  );
};

export default TwoColumnComponent;
