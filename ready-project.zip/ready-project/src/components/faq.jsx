import React, { useState, useRef, useEffect } from "react";


const faqs = [
  {
    question: "Do you offer a free trial?",
    shortAnswer: "Yes! We're confident in our work ,",
    fullAnswer:
      "so we'll edit one of your files for free. It's the best way to see our quality firsthand, with no strings attached and no credit card required.",
  },
  {
    question: "Which image and video file formats do you accept?",
    shortAnswer: "We accept all common image formats,",
    fullAnswer:
      "including JPEG, PNG, PSD, TIFF, and RAW. For video, we handle all standard formats like MP4, MOV. If you have a different format, just let us know!",
  },
  {
    question: "How do I get my free trial?",
    shortAnswer: "Simply fill out the contact form",
    fullAnswer:
      "at the bottom of the page and upload the file you'd like us to work on. Our team will get back to you with the edited file as soon as it's ready.",
  },
  {
    question: "Do you offer support after delivery?",
    shortAnswer: "We offer easy communication through our client portal,",
    fullAnswer:
      "email, and live chat. We are here to answer your questions and keep you updated every step of the way.",
  },
  {
    question:"How does the set 'your own price' model work?",
    shortAnswer:"Once you've had your free trial,",
    fullAnswer:"you simply tell us your budget. We believe in providing exceptional quality at a price that's comfortable for you."
  },
    {
    question:"Are my photos and information safe with Attest Design?",
    shortAnswer:"Absolutely,",
    fullAnswer:"We use a secure FTP AWS server and encrypted connections to ensure your files and data are always protected. Your privacy is our priority."
  },
    {
    question:"What is your turnaround time?",
    shortAnswer:"Turnaround time depends on the project's complexity",
    fullAnswer:"and size, but we always aim for a fast delivery without compromising quality."
  },
  {
    question:"What if I'm not satisfied with the result?",
    shortAnswer:"We're committed",
    fullAnswer:"to making sure you're thrilled with our work. If the final result doesn't meet your expectations, we won't rest until we make it right."
  }
];

export default function FAQSection() {
  const [expandedIndex, setExpandedIndex] = useState(null);
  const contentRefs = useRef([]);

  // Detect if the device is touch-capable
  const isTouchDevice = () =>
    "ontouchstart" in window || navigator.maxTouchPoints > 0;

  useEffect(() => {
    contentRefs.current.forEach((el, i) => {
      if (!el) return;
      if (expandedIndex === i) {
        el.style.maxHeight = `${el.scrollHeight}px`;
        el.style.opacity = "1";
      } else {
        el.style.maxHeight = "0px";
        el.style.opacity = "0";
      }
    });
  }, [expandedIndex]);

  const toggleExpand = (index) => {
    setExpandedIndex((prev) => (prev === index ? null : index));
  };

  return (
    <section className="faq-section py-4">
      <div className="container">
        <div className="text-center mb-5">
          <h2>Frequently Asked Questions</h2>
          <h4 className="text-muted">Quick answers to the most common queries</h4>
        </div>

        <div className="row g-4">
          {faqs.map((faq, index) => (
            <div className="col-12 col-md-6" key={index}>
              <div
                className="card shadow-sm border-0 h-100 faq-card"
                onClick={() => toggleExpand(index)}
                {...(!isTouchDevice() && {
                  onMouseEnter: () => setExpandedIndex(index),
                  onMouseLeave: () => setExpandedIndex(null),
                })}
              >
                <div className="card-body">
                  <h5 className="fw-bold">{faq.question}</h5>

                  <div className="mt-2 d-flex align-items-center justify-content-between short-answer">
                    <p className="text-muted mb-0">{faq.shortAnswer}</p>
                    <span
                      className={`triangle ${
                        expandedIndex === index ? "open" : ""
                      }`}
                    />
                  </div>

                  <div
                    className="expandable"
                    ref={(el) => (contentRefs.current[index] = el)}
                  >
                    <p className="text-muted mb-0">{faq.fullAnswer}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
