

function Curve() {
  return (
    <section className="curve-section">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 1440 200"
        preserveAspectRatio="none"
        className="curve-svg"
      >
        <path
          fill="#ffffff"
          d="
            M0,120
            C288,40 432,140 576,80
            C720,20 864,180 1008,120
            C1152,60 1296,160 1440,100
            L1440,0 L0,0 Z
          "
        />
      </svg>
    </section>
  );
}


export default Curve;