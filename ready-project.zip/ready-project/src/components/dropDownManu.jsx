import React, { useState, useRef, useEffect } from "react";

const MultiSelectDropdown = ({ options }) => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = () => setIsOpen(!isOpen);

  const handleSelect = (item) => {
    if (!selectedItems.includes(item)) {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const handleRemove = (item) => {
    setSelectedItems(selectedItems.filter((i) => i !== item));
  };

  return (
    <div className="dropdown mb-3" ref={dropdownRef}>
      {/* Input / Button */}
      <div
        className="form-control d-flex flex-wrap align-items-center w-100"
        onClick={toggleDropdown}
        style={{ minHeight: "45px", cursor: "pointer" }}
      >
        {selectedItems.length === 0 && (
          <span className="text-muted">Select services...</span>
        )}

        {selectedItems.map((item) => (
          <span
            key={item}
            className="badge bg-primary text-white me-1 mb-1 d-flex align-items-center"
          >
            {item}
            <button
              type="button"
              className="btn-close btn-close-white btn-sm ms-1"
              aria-label="Remove"
              onClick={(e) => {
                e.stopPropagation(); // prevent dropdown toggle
                handleRemove(item);
              }}
            ></button>
          </span>
        ))}
      </div>

      {/* Dropdown menu */}
      {isOpen && (
        <ul
          className="dropdown-menu show w-100 mt-0"
          style={{ maxHeight: "200px", overflowY: "auto" }}
        >
          {options.map((option) => (
            <li key={option}>
              <button
                className="dropdown-item"
                type="button"
                onClick={() => handleSelect(option)}
                disabled={selectedItems.includes(option)}
              >
                {option}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MultiSelectDropdown;
