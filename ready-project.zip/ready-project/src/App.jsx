
import Header from "./components/header"
import TwoColumnSection from "./components/title_formsection"

import "./app.css"
import Portfolio from "./components/Portfolio"
import Footer from "./components/footer"
import OrderProcess from "./components/orderProcess"
import FAQSection from "./components/faq"
import WhyUs from "./components/WhyUs"
import Curve from "./components/Curve" 

export default function App(){


return (<div className="landing_page">
    <Header/>
    <TwoColumnSection/>
    <Portfolio/>
    <div className="live-gradient">
        <Curve/>
        <OrderProcess/>
        <FAQSection/>
        <WhyUs/>
        <Footer/>
    </div>
</div>)
}


