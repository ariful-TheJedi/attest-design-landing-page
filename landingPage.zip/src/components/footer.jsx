

export default function Footer(...props){


return (
<footer class="footer bg-light pt-5">
  <div class="container">
    <div class="row align-items-center gy-4">

      <div class="col-md-auto d-flex justify-content-center">
        <img src="https://dashboard.attestdesign.com/website/img/logo-icon.png" class="footer-logo" alt="Logo" />
      </div>

      <div class="col text-center text-md-start">
        <h6>Corporate Office</h6>
        <p class="mb-2">
          26/2 Central Road, Ground Floor,<br />
          New Market, Dhaka-1205, Bangladesh
        </p>
        <h6>Administrative Office</h6>
        <p class="mb-2">
          27, Old Gloucester Street,<br />
          London, WC1N 3AX, United Kingdom
        </p>
        <p class="mb-1">
          <img src="https://dashboard.attestdesign.com/website/img/ico-phone.svg" class="me-2" /> +88 01332 53 31 77
        </p>
        <p>
          <img src="https://dashboard.attestdesign.com/website/img/ico-email.svg" class="me-2" /> info@attestdesign.com
        </p>
      </div>

      <div class="col text-center text-md-start">
        <h6>Payment Options</h6>
        <img src="https://dashboard.attestdesign.com/website/img/paymentsv2.svg?v=2" class="img-fluid" />
        <p class="pt-3 mb-0">Follow us</p>
        <div class="d-flex justify-content-center justify-content-md-start gap-2 mt-1">
          <a href="https://www.facebook.com/people/Attest-Design-Ltd/61574719254306/"><img src="https://dashboard.attestdesign.com/website/img/fb.png" /></a>
          <a href="https://www.instagram.com/attest_design/"><img src="https://dashboard.attestdesign.com/website/img/insta.png" /></a>
          <a href="https://www.linkedin.com/company/attestdesignltdglobal/"><img src="https://dashboard.attestdesign.com/website/img/in.png" /></a>
          <a href="https://www.pinterest.com/AttestDesign2025/"><img src="https://dashboard.attestdesign.com/website/img/pin.png" /></a>
          <a href="https://www.youtube.com/@AttestDesign"><img src="https://dashboard.attestdesign.com/website/img/yt.png" /></a>
          <a href="https://x.com/Attest_Design"><img src="https://dashboard.attestdesign.com/website/img/x.png" /></a>
        </div>
      </div>

      <div class="col text-center text-md-start">
        <h6>Quick Links</h6>
        <ul class="list-unstyled mb-0 footer-links">
          <li><a href="https://dashboard.attestdesign.com/contact-us">CONTACT US</a></li>
          <li><a href="https://attestdesign.com/blog">BLOG</a></li>
          <li><a href="https://attestdesign.com/faq">FAQ</a></li>
          <li><a href="https://attestdesign.com/terms-and-conditions">TERMS AND CONDITIONS</a></li>
          <li><a href="https://attestdesign.com/privacy-policy">PRIVACY POLICY</a></li>
          <li><a href="https://attestdesign.com/data-security-policy">DATA SECURITY POLICY</a></li>
        </ul>
      </div>

      <div class="col-md-auto d-flex justify-content-center">
        <a href="https://wa.me/8801332533177">
          <img src="https://dashboard.attestdesign.com/website/img/whatsapp.png?v=2" class="footer-whatsapp" />
        </a>
      </div>

    </div>

    <div class="row pt-5">
      <div class="col text-center">
        <p class="mb-0">© Attest Design | 2025</p>
      </div>
    </div>
  </div>
</footer>

    )
}