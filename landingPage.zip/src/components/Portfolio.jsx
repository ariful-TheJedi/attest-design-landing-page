import React from "react";
import BeforeAfterSlider from "./beforeAfter";


const sampleData = [
    {
        name:"Clipping Path",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Clipping-Path-After.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Clipping-Path-before.jpg"
    },
    {
        name:"Background Removal",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Background-Removal-After.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Background-Removal-before.jpg"
    },
    {
        name:"Ghost Mannequin Effect",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Ghost-Mannequin-Effect-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Ghost-Mannequin-Effect-before.jpg"
    },
    {
        name:"Image Masking",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Image-Masking-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Image-Masking-before.jpg"
    },
    {
        name:"Photo Retouching",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Photo-Retouching-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Photo-Retouching-before.jpg"
    },
    {
        name:"Color Correction",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Color-Correction-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Color-Correction-before.jpg"
    },
    {
        name:"Photography Post-Processing",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Photography-Post-Processing-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Photography-Post-Processing-before.jpg"
    },
    {
        name:"E-commerce Product Image Editing",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/E-commerce-Product-Image-Editing-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/E-commerce-Product-Image-Editing-before.jpg"
    },
    {
        name:"Motion Graphics",
        aftersrc:"https://dashboard.attestdesign.com/assets/images/bna/Motion-graphic-after.png",
        beforesrc:"https://dashboard.attestdesign.com/assets/images/bna/Motion-graphic-before.jpg"
    }
]


export default function Portfolio(){


  return (
    <section className="py-5 portfolio">
      <div className="container">
        {/* Title and Subtitle */}
        <div className="text-center mb-4">
          <h2 className="fw-bold">SEE OUR WORK IN ACTION</h2>
          <h4 className="text-muted">Don't just take our word for it—see the results for yourself.</h4>
        </div>

        {/* Image Grid */}
        <div className="row g-4">
          {/* <div className="col-6 col-md-4 col-lg-3">
            <div className="image-container rounded">
              <BeforeAfterSlider
                beforeSrc="https://dashboard.attestdesign.com/assets/images/bna/Background-Removal-before.jpg"
                afterSrc="https://dashboard.attestdesign.com/assets/images/bna/Background-Removal-After.png"
              />
            </div>
          </div> */}
          {/* <div className="col-12 col-md-6 col-lg-4">
            <div className="image-container text-center">
              <img
                src="https://dashboard.attestdesign.com/assets/images/bna/Background-Removal-before.jpg"
                alt="Image 1"
                className="img-fluid w-100"
              />
              <h5 className="mt-2">Cliping Path</h5>
            </div>
          </div> */}
          {sampleData.map(
            (data) => {
                return (
                    <div className="col-12 col-md-6 col-lg-4">
                        <div className="image-container text-center">
                         <BeforeAfterSlider
                           beforeSrc={data.beforesrc}
                           afterSrc={data.aftersrc}
                         />
                        <h5 className="mt-2">{data.name}</h5>
                        </div>
                    </div>   
                )
            }
          )}
        </div>
      </div>
    </section>
  );
};

