import React, { useState } from "react";
import MultiSelectDropdown from "./dropDownManu";



const services = [
  "Background Removal",
  "Color Correction",
  "Clipping Path",
  "E-commerce Product Image Editing",
  "Ghost Mannequin",
  "Image Masking",
  "Photo Retouching Services",
  "Photography Post-Processing",
  "Video Production"
];

const ContactForm = () => {
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState("");

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      const maxSize = 500 * 1024 * 1024; // 500MB in bytes
      if (selectedFile.size > maxSize) {
        setFile(null);
        setFileError("File size exceeds 500MB limit!");
      } else {
        setFile(selectedFile);
        setFileError("");
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file) {
      setFileError("Please upload a valid file!");
      return;
    }

    // Add your submission logic here (API call, etc.)
    alert("Form submitted successfully!");
  };

  return (
    <div className="container my-1">
      <form onSubmit={handleSubmit} className="p-4 bg-light rounded shadow">
        {/* Name */}
        <div className="mb-3">
          <label htmlFor="name" className="form-label fw-bold">
            Name*
          </label>
          <input
            type="text"
            className="form-control"
            id="name"
            placeholder="Enter your name"
            required
          />
        </div>

        {/* Email */}
        <div className="mb-3">
          <label htmlFor="email" className="form-label fw-bold">
            Email*
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            placeholder="Enter your email"
            required
          />
        </div>

        {/* Select Service */}
        <div className="dropdown mb-3">
          <label htmlFor="email" className="form-label fw-bold">
            Chooge Our Services*
          </label>
         <MultiSelectDropdown options={services}/>
        </div>

        {/* Description */}
        <div className="mb-3">
          <label htmlFor="description" className="form-label fw-bold">
            Description
          </label>
          <textarea
            className="form-control"
            id="description"
            rows="4"
            placeholder="Write your message"
            required
          ></textarea>
        </div>

        {/* File Upload */}
        <div className="mb-3">
          <label htmlFor="file" className="form-label fw-bold">
            Upload File (Max 500MB)
          </label>
          <input
            type="file"
            className="form-control"
            id="file"
            onChange={handleFileChange}
            required
          />
          {file && (
            <small className="text-success">
              File uploaded: {file.name} ({(file.size / (1024 * 1024)).toFixed(2)} MB)
            </small>
          )}
          {fileError && <small className="text-danger">{fileError}</small>}
        </div>

        {/* CAPTCHA Placeholder */}
        <div className="mb-3">
          <label className="form-label fw-bold">CAPTCHA</label>
          <div className="p-3 bg-secondary text-white text-center rounded">
            [CAPTCHA Placeholder]
          </div>
        </div>

        {/* Submit Button */}
        <center>
          <button type="submit" className="contact-form-submit btn px-4 py-2 rounded-pill shadow fw-bold">
            START A FREE TRIAL
          </button>
        </center>
      </form>
    </div>
  );
};

export default ContactForm;
