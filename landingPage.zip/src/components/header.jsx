import React from "react";

function Header(){
    return (
    <nav className="bg-light shadow-sm py-3">
      <div className="container">
        <div className="row align-items-center">
          {/* Logo Column */}
          <div className="col-12 col-md-6 d-flex justify-content-center justify-content-md-start mb-3 mb-md-0">
             <img
              src="https://dashboard.attestdesign.com/website/img/logo_n.svg"
              alt="Logo"
              height="40"
            />
          </div>

          {/* Button Column */}
          <div className="col-12 col-md-6 d-flex justify-content-center justify-content-md-end">
            <button className="header-action-btn btn  px-4 py-2 rounded-pill fw-bold shadow">
              START A FREE TRIAL
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
